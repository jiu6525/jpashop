package jpabook.jpashop;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class hello {

    private String data;
}
